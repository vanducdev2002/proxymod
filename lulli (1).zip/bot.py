import discord
from discord import app_commands
from discord.ext import commands
import os


TOKEN = "DISCORD BOT TOKEN"
UID_FILE = "uid.txt"


intents = discord.Intents.default()
client = commands.Bot(command_prefix="!", intents=intents)

@client.event
async def on_ready():
    print(f'🌍 Public Bot is online as {client.user}')
    try:
        synced = await client.tree.sync()
        print(f'✅ Synced {len(synced)} commands.')
    except Exception as e:
        print(f'❌ Error syncing: {e}')


@client.tree.command(name="adduid", description="Add your Free Fire UID to the Proxy Whitelist")
@app_commands.describe(uid="Your UID (Numbers only)")
async def adduid(interaction: discord.Interaction, uid: str):
    

    if not uid.isdigit():
        await interaction.response.send_message(f"❌ **Error:** UID must contain numbers only.", ephemeral=True)
        return

    if len(uid) < 5 or len(uid) > 20:
        await interaction.response.send_message(f"❌ **Error:** Invalid UID length.", ephemeral=True)
        return


    current_uids = []
    if os.path.exists(UID_FILE):
        with open(UID_FILE, "r") as f:

            current_uids = [line.strip() for line in f.readlines() if line.strip()]


    if uid in current_uids:
        await interaction.response.send_message(f"⚠️ **UID {uid}** is already registered!", ephemeral=True)
        return

   
    current_uids.append(uid)

    try:
        with open(UID_FILE, "w") as f:
    
            f.write("\n".join(current_uids) + "\n")

        print(f"[BOT] User {interaction.user} added UID: {uid}")
        await interaction.response.send_message(f"✅ **Success!** UID `{uid}` added.", ephemeral=False)

    except Exception as e:
        await interaction.response.send_message(f"❌ System Error: {e}", ephemeral=True)


client.run(TOKEN)